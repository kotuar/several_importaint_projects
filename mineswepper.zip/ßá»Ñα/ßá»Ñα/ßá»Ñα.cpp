﻿#include <SFML/Graphics.hpp>
#include <ctime>
#include <SFML/Audio.hpp>
using namespace sf;

int main() {
	srand(time(0));
	int size = 32;
	Image Icon;
	Image lose;
	RenderWindow window1(VideoMode(320, 320), "mineSwiper");//рендер-отрисовка окна создали поле 320 на 320
	Icon.loadFromFile("F:/dowload opera/icon.png");//фавиконка
	window1.setIcon(360, 360, Icon.getPixelsPtr());
	Texture box;
	lose.loadFromFile("F:/dowload opera/gameOver.jpg");
	Texture lose1;
	lose1.loadFromImage(lose);
	Sprite lose2;
	lose2.setTexture(lose1);
	SoundBuffer boom;
	boom.loadFromFile("F:/dowload opera/boom.wav");
	Sound bomb(boom);
	box.loadFromFile("F:/dowload opera/texture.jpg");//текстурка клеточки
	Sprite cletka(box); //спрайт это модель обьекта в виде растрового изображения//спрайт в виде текстуры с названием бокс;
	int startField[12][12];//размер клетки 12 на 12
	int gameField[12][12];//одно где мины 2 где кнопки
	for (int i = 0; i < 10; i++)//заполняем поле по x y пустыми нажимными плитами
		for (int j = 0; j < 10; j++) {
			startField[i][j] = 10;// i j потому что двойной массив а 10 это индекс нажимной плиты на картинке
			if (rand() % 5 == 0)//5 потому то у нас 5 классов клеток а 0 это мина
				gameField[i][j] = 9; //9 это индекс мины
			else
				gameField[i][j] = 0;//0 это индекс пустой клетки
		}
	for (int i = 0; i < 11; i++)
		for (int j = 0; j < 11; j++) {
			int n = 0;//счетчик мин
			if (gameField[i][j] == 9)// если в клетке мина считаем мины чтобы расставить цифры
				continue;
			if (gameField[i + 1][j] == 9)
				n++;
			if (gameField[i + 1][j + 1] == 9)
				n++;
			if (gameField[i][j + 1] == 9)
				n++;
			if (gameField[i + 1][j - 1] == 9)
				n++;
			if (gameField[i][j - 1] == 9)
				n++;
			if (gameField[i - 1][j] == 9)
				n++;
			if (gameField[i - 1][j + 1] == 9)
				n++;
			if (gameField[i - 1][j - 1] == 9)
				n++;
			gameField[i][j] = n;// посчитали мины чтобы поставить циферку
		}
	while (window1.isOpen()) {//выполняем пока окно открыто
		Vector2i mouse = Mouse::getPosition(window1);//направление нашей мыши 2 это двухмерное пространство а i это интегер для вектора
		int x = mouse.x / size; //чтобы не делил каждую клетку на 32 вектора
		int y = mouse.y / size;
		Event click;//событие клик
		while (window1.pollEvent(click)) {//потому что работает пока мы в проге мышь держим и обработка нашего события
			if (click.type == Event::MouseButtonPressed) {// если тип нашего события это нажатие клавиши
				if (click.key.code == Mouse::Left)//если код нашего нажатия это левая кнопка мыши
					startField[x][y] = gameField[x][y];//положение на нашем поле меняется с положение на игровом поле
				if (startField[x][y] == 9) {

					bomb.play();
				}
				else if (click.key.code == Mouse::Right)
					startField[x][y] = 11;//если нажали правую кнопку мыши то ставим флажок
			}
			if (click.type == Event::Closed)//если мы нажали крестик то закрываем окно
				window1.close();
		}
		window1.clear(Color::Blue);//задний фон белый
		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 10; j++) {
				if (startField[x][y] == 9) {//если наступили на мину то
					startField[i][j] = gameField[i][j];
				}
				cletka.setTextureRect(IntRect(startField[i][j] * size, 0, size, size));//старт филд потому что он хранит в себе размеры каждого кубика//*32 так как мы делаем каждый квадратик
				cletka.setPosition(i * size, j * size);//умножение так как мы делаем каждый квадратик
				window1.draw(cletka);
				if (startField[x][y] == 9) {
					RenderWindow window2(VideoMode(580, 320), "You are Loser!");
					while (window2.isOpen()) {
						while (window2.pollEvent(click)) {
							if (click.type == Event::Closed) {//если мы нажали крестик то закрываем окно
								window2.setVisible(false);
							}
							window2.draw(lose2);
							window2.display();
						}
					}
				}
			}
		window1.display();
	}
}
